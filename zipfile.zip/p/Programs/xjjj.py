import sqlite3
from time import time, ctime


class DB:
    def __init__(self):
        conn = sqlite3.connect("news.db", check_same_thread=False)
        self.conn = conn
    
    def get_connection(self):
        return self.conn

    def __del__(self):
        self.conn.close()
db = DB()


class UsersModel:
    def __init__(self, connection):
        self.connection = connection

    def init_table(self):
        cursor = self.connection.cursor()
        cursor.execute("""CREATE TABLE IF NOT EXISTS users
                              (id INTEGER PRIMARY KEY AUTOINCREMENT,
                               user_name VARCHAR(50),
                               password_hash VARCHAR(128)
                              )""")
        cursor.close()
        self.connection.commit()

    def insert(self, user_name, password_hash):
        cursor = self.connection.cursor()
        cursor.execute("""INSERT INTO users
                          (user_name, password_hash)
                          VALUES (?,?)""", (user_name, password_hash))
        cursor.close()
        self.connection.commit()

    def get(self, user_id):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM users WHERE id = ?", (str(user_id),))
        row = cursor.fetchone()
        return row

    def get_all(self):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM users")
        rows = cursor.fetchall()
        return rows

    def exists(self, user_name, password_hash):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM users WHERE user_name = ? AND password_hash = ?",
                       (user_name, password_hash))
        row = cursor.fechone()
        return (True, now[0]) if row else (False,)

    def delete(self, user_id):
        cursor = self.connection.cursor()
        cursor.execute('''DELETE FROM users WHERE id = ?''', (str(user_id),))
        cursor.close()
        self.connection.commit()


from flask import Flask
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired

import json

from flask import Flask
from flask import url_for
from flask import request
from flask import redirect
from flask import render_template
from flask import session

from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileRequired
from wtforms import StringField, PasswordField, RadioField
from wtforms import BooleanField, SubmitField, SelectField
from wtforms.validators import DataRequired
from flask import url_for, request
from random import choice
from index import gen_audio
 

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'



class LoginForm(FlaskForm):
    username = StringField('Логин', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    submit = SubmitField('Войти')


class RegistrationForm(FlaskForm):
    username = StringField("Логин", validators=[DataRequired()])
    password = PasswordField("пАроль", validators=[DataRequired()])
    password_rep = PasswordField("Повторите пАроль", validators=[DataRequired()])
    submit = SubmitField("Зарегистрироваться")


@app.route('/')
@app.route('/form_sample', methods=['POST', 'GET'])
def low_button():
    if 'username' not in session:
        return redirect('/login')
    letters = [".-", "-...", "-.-.", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--.."]
    if request.method == 'GET':
        n = 0
    elif request.method == "POST":
        n = int(request.form['class'])
    lessons = open("lessons.txt", "r").read().split("\n")
    inp = str()
    for i in range(1, 41):
        inp += choice(lessons[int(n)])
        if i % 4 == 0:
            inp += " "
    gen_audio(inp)
    gen_audio(lessons[int(n)][-1], name="letter.wav")
    return '''<!doctype html>
                    <html lang="en">
                      <head>
                        <meta charset="utf-8">
                        <meta name="viewport"
                        content="width=device-width, initial-scale=1, shrink-to-fit=no">
                        <link rel="stylesheet" 
                        href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
                        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
                        crossorigin="anonymous">
                        <title>Пример формы</title>
                        <script>
                          function check() {}
                            var a = document.getElementById("about");
                            var b = "{}";
                            var k = Math.abs(b.length - a.value.length);
                            for(var i = 0; i < Math.min(a.length, b.length); ++i){}
                              if (a.value.toLowerCase().charAt(i) != b.charAt(i)) k ++;
                            {}
                            a.value = "Получено:\\n" + a.value.toLowerCase() + "\\nОтправлено:\\n" + b + "\\nОшибок:" + k.toString();
                            {}
                        </script>
                      </head>
                      <body>
                        <form method="post">
                            <div class="form-group">
                               
                                <label id="br" style="position: absolute; top:0px; left:90px; width:210px; height:25px"><b>Изучение морзы</b></label>

                                <label style="position: absolute; top:0px; left:10px; width:70px; height:25px" for="classSelect">урок</label>
                                <audio controls style="position: absolute; top:185px; left:0px;">
                                  <source src="static/audio/lesson.wav" type="audio/wav">
                                  Your browser does not support the audio element.
                                </audio>
                                
                                <audio controls style="position: absolute; top:105px; left:0px;">
                                  <source src="static/audio/letter.wav" type="audio/wav">
                                  Your browser does not support the audio element.
                                </audio>
                                
                                <label style="position: absolute; top:80px; left:10px; width:290px; height:10px" for="about">знакомьтесь, буква {}</label>
                                <label style="position: absolute; top:160px; left:10px; width:295px; height:10px" for="about">запишите то что услышите</label>
                                <textarea class="form-control" id="about" rows="3" name="about" style="position: absolute; font-size:125%; top:250px; left:0px; width:300px; height:100px"></textarea>
                                <button type="submit" class="btn btn-primary" style="position: absolute; top:30px; left:80px; width:220px; height:50px;" action="num.py">выбрать</button>                     
                                <select class="form-control" id="classSelect" name="class" style="position: absolute; top:30px; left:0px; width: 70px; height: 50px;">
                                  <option selected>{}</option>
                                  <option>0</option>
                                  <option>1</option>
                                  <option>2</option>
                                  <option>3</option>
                                  <option>4</option>
                                  <option>5</option>
                                  <option>6</option>
                                  <option>7</option>
                                  <option>8</option>
                                  <option>9</option>
                                  <option>10</option>
                                  <option>11</option>
                                  <option>12</option>
                                  <option>13</option>
                                  <option>14</option>
                                  <option>15</option>
                                  <option>16</option>
                                  <option>17</option>
                                  <option>18</option>
                                  <option>19</option>
                                  <option>20</option>
                                  <option>21</option>
                                  <option>22</option>
                                  <option>23</option>
                                  <option>24</option>
                                  <option>25</option>
                                  
                                </select>
                            </div>
                            <button type="button" class="btn btn-primary" style="position: absolute; top:355px; left:0px; width:300px; height:50px" value="himyfriend" onclick="check()">отправить на проверку</button>
                        </form>
                      </body>
                    </html>'''.format("{", inp, "{", "}", "}", str(lessons[int(n)][-1]), str(n))
 


@app.route("/add_user", methods=["GET", "POST"])
def add_user():
    form = RegistrationForm()
    um = UsersModel( db.get_connection() )
    um.init_table()
    if form.validate_on_submit() and form.password.data != form.password_rep.data:
        form.password.errors.append("извините, пожалуйста, но вы совершили ошибочку, видите-ли, пароли не совпадают, что вызывает во мне бесконечную печаль и сострадание, однако это не помогает ситуациии, все-таки, пароль введёный вами второй раз не совпадает с паролем, введённым в первый. и кому-то придется исправить эту оплошность, и, явно не мне, поскольку я не могу ничего сделать. пожалуйста исправьте эту оплошность, иначе вы не сможете зайти в систему, и, я не знаю, оставить новость для своего дневника что=ли")
    elif form.validate_on_submit():
        um = UsersModel( db.get_connection() )
        um.init_table()
        username = form.username.data
        password_hash = form.password_rep.data        
        for person in um.get_all():
            if person[1] == username:
                form.username.errors.append("Мы просим полного понимания и вашего прощения за то что НИКНЕЙМ КОТОРЫЙ ВЫ ВВЕЛИ УЖЕ ЗАРЕГИСТРИРОВАН В НАШЕЙ БАЗЕ ДАННЫХ БЛИН, попробуйте другой никнейм пожалуйста, в ином случае вы не сможете продолжать действовать на этом сайте ((((")
                break
        else:
            um.insert(username, password_hash)
            session["username"] = username
            session["user_id"] = um.get_all()[-1][0]
            return redirect("/form_sample")
        return render_template("signup.html", title="РЕгистРАЦИЯ", form=form)
    return render_template("signup.html", title="РЕгистРАЦИЯ", form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    
    if form.validate_on_submit():
        username = form.username.data
        password_hash = form.password.data
        
        for person in UsersModel(db.get_connection()).get_all():
            if person[1] == username and person[2] == password_hash:
                session["username"] = username
                session["user_id"] = person[0]
                return redirect("/form_sample")
            elif person[1] == username:

                form.username.errors = []
                form.username.errors.append("Имя логина совпадает, а вот пароль нет, в этом есть небольшая проблема, пожаулйста попытайтесь исправить ее, иначе вы не сможете зайти в аккаунт")
                return render_template('login.html', title='Авторизация', form=form)

        form.username.errors = []        
        form.username.errors.append("Имя логина не зарегистрировано в базе данных, попробуйте зарегистрироваться))))")
        return render_template('login.html', title='Авторизация', form=form)
    
    return render_template('login.html', title='Авторизация', form=form)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')

