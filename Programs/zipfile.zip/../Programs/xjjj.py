from flask import Flask
from flask import url_for
 
app = Flask(__name__)

 
@app.route('/')
@app.route('/image_puzzle/<n>')
def youtube(n):
    n = int(n)
    k = ""
    if n > 16:
        return "ОШИБКА ЧИСЛО СЛИШКОМ БОЛЬШОЕ"
    elif n < 1:
        return "ОШИБКА ЧИСЛО СЛИШКОМ МАЛЕНЬКОЕ"
    for a in range(4):
        for b in range(4):
            if a + b * 4 == n - 1:
                continue
            k += """<img style="position: absolute; top:{}px; left:{}px; width:240px; height:320px" src="/static/img/58_{}_{}.jpg">""".format(str(320 * b), str(240 * a), str(a), str(b))
    return k
 
if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')

