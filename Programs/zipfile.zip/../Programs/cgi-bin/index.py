#!/usr/bin/python

print("Content-type: text/html")
print()
print("<h1>«Привет, Яндекс! Я - {ВАШЕ ИМЯ}»</h1>")
